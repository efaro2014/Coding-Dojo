print('Hello World')
name = 'Efrem'
print('Hello', name)
name = 'Efrem'
print('Hello ' + name)
num = 7
print('Hello', num)
print('Hello' + str(num))
food_one = 'Pizza'
food_two = 'Tibs'
print('“I love to eat {} and {}'.format(food_one, food_two))
print(f'I love to eat {food_one} and {food_two}')
