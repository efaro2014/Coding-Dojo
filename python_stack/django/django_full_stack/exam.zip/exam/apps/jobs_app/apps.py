from django.apps import AppConfig


class JobsAppConfig(AppConfig):
    name = 'jobs_app'
