from django.apps import AppConfig


class HomeAppConfig(AppConfig):
    name = 'home_app'
