public class FizzBuzzTest{
    public static void main(String[] args){
        FizzBuzz id = new FizzBuzz();
        String fizzbuz = id.fizzBuzz(5);
        System.out.println(fizzbuz);
    }
}