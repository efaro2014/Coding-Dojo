public class BasicsTest{
    public static void main(String[] args){
        Basics id = new Basics();
        Integer max = id.largest();
        System.out.println(max);
    }
}


