public class PythagoreanTest{
    public static void main(String[] args){
        Pythagorean id = new Pythagorean();
        double num = id.calculateHypotenuse();
        System.out.println(num);
    }
}