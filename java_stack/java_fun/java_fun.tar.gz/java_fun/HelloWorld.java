// public class HelloWorld{
//     public static void main(String[] args){
//         System.out.println("hello world");
//         System.out.println("age = 32");
//         System.out.println("I live in San Francisco");
//     }
// }

// public class HelloWorld{
//     public static void main(String[] args) {
//     long start = System.currentTimeMillis();
//     int sum = 0;
//     for (int i = 0; i < Integer.MAX_VALUE; i++) {
//         sum += i;
//     }
//     System.out.println("Sum: " + sum);
//     long end = System.currentTimeMillis();
//     double total = (double) (end - start) / 1000;
//     System.out.println("Time of execution: " + total + " seconds");
//     }
// }


public class HelloWorld{
    public static void main(String[] args){
    //    String ninja = String.format("Hi %s, you owe me %s !", "Jack", 25.0);
    //     System.out.println(ninja);
        // String ninja = "Welcome to Coding Dojo!";
        // int a = ninja.indexOf("Coding"); // a is 11
        // int b = ninja.indexOf("co"); // b is 3
        // int c = ninja.indexOf("pizza"); // c is -1, "pizza" is not found
        // System.out.println(a);
        int a = 5;
        int b = 25;
        System.out.println(b/a);
    }
}
