public class ImportDemoTest{
    public static void main(String[] args){
        ImportDemo id = new ImportDemo();
        String currentDate = id.getCurrentDate();
        System.out.println(currentDate);
    }
}